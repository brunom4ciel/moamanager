<?php
// exit("bruno");
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 1);

if (! Framework::is_authentication())
    Framework::alert("Error: you do not have credentials.");

$error_msg = "";

Framework::includeLib("Utils.php");

$utils = new Utils();

$dirpath = Framework::getBase_directory_moa() . "datasets" . App::getDirectorySeparator();

if (isset($_GET['download'])) {
    if (! empty($_GET['download'])) {

        $filename = $_GET['download'];
        $filePath = $dirpath . $filename;

        if (! is_readable($filePath))
            die('File not found or inaccessible - ' . $filename);

        if (! is_file($filePath))
            die('Found inaccessible - ' . $filename);

        $size = filesize($filePath);

        // header('Content-Type: application/zip');
        header('Content-Type: application/octet-stream');
        header("Content-Transfer-Encoding: Binary");
        header("Content-Length: " . $size);

        header("Content-Disposition: attachment; filename=\"" . $filename . "\"");
        set_time_limit(0);

        $file = @fopen($filePath, "rb");
        while (! feof($file)) {
            print(@fread($file, 1024 * 8));
            ob_flush();
            flush();
        }

        exit();
    }
}

$files_list_datasets = $utils->getListElementsDirectory(Framework::getBase_directory_moa() . "datasets/", array(
    "arff"
));

asort($files_list_datasets);

?>



<div class="content content-alt">
	<div class="container" style="width: 70%">
		<div class="row">
			<div class="">
				<div class="card" style="width: 100%">



					<div class="page-header">
						<h1>Datasets</h1>
					</div>
							
							<?php

    if (! empty($error_msg)) {

        echo $error_msg;
    }
    ?>
							
							
							<table>
            				<?php

                // for($i=0; $i<count($files_list_datasets); $i++){
                foreach ($files_list_datasets as $file) {

                    echo "<tr><td><a href='?component=" . App::getComponent() . "&controller=" . App::getController() . "&download=" . rawurlencode($file) . "'>" . $file . "</a></td>" . "<td>(" . $utils->formatSize(filesize(Framework::getBase_directory_moa() . "datasets/" . $file)) . ")" . "</td>" . "<td> " . date("d/j/Y H:i:s", filemtime(Framework::getBase_directory_moa() . "datasets/" . $file)) . "</td></tr>\n";
                }

                ?>
							</table>

				</div>

			</div>
		</div>
	</div>
</div>
</div>

