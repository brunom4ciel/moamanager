<?php
if (! Framework::is_authentication())
    Framework::alert("Error: you do not have credentials.");

$task = App::getParameter("task");

$status_msg = "Are you sure you want to delete your account?
												<br>
												If the account is delete all files related to this account will be deleted as well.
												<br>
												<br>
												User Directory:<br>
												" . App::getBase_directory_destine() . App::getUser() . "
															
															<br><br>";
$buttons = true;

if ($task == "remove") {

    if (App::getAcl_autoremove_account() == true) {

        Framework::includeLib("Utils.php");
        Framework::includeLib("Crypt.php");
        Framework::includeLib("User.php");

        $utils = new Utils();
        $user = new User(Framework::getPassphrase());

        $from_folder = App::getBase_directory_destine() . App::getUser() . App::getDirectorySeparator();

        if (is_dir($from_folder)) {

            // exit($from_folder);
            $utils->delTree($from_folder);

            $user->remove(App::getUser());

            App::logout();

            header("Location: " . Framework::rootApp() . "?component=user&controller=login&logout");
        }
    } else {
        $buttons = false;
        $status_msg = "The administrator user does not allow the account to be excluded. <br>Security policy <i>acl_autoremove_account</i> this set to <b>false</b> in Properties.php.";
    }
}

?>
<div class="content content-alt">
	<div class="container" style="width: 90%">
		<div class="row">
			<div class="">

				<div class="card" style="width: 100%">
					<div class="page-header">
						<h1>
							<a href="<?php echo $_SERVER['REQUEST_URI']?>">Remove Account</a>
						</h1>
					</div>

					<div style="width: 100%; padding-bottom: 15px; display: table">

						<div style="float: left; width: 200px; border: 1px solid #fff"></div>

						<div style="float: left; width: 80%; border: 1px solid #fff">


							<form method="POST" action="<?php echo $_SERVER['PHP_SELF'];?>"
								name="saveform" async-form="login"
								class="ng-pristine ng-valid-email ng-invalid ng-invalid-required">
								<input type="hidden" value="<?php echo App::getComponent()?>"
									name="component"> <input type="hidden"
									value="<?php echo App::getController()?>" name="controller"> <input
									type="hidden" value="remove" name="task" id="task">

								<div style="float: left; padding-left: 20px; width: 100%">

									<div
										style="float: left; padding-left: 5px; width: 100%; margin-top: 5px;">
												
												<?php echo $status_msg;?>
												
											</div>


									<div style="float: right; padding-left: 10px">
											<?php if($buttons){?>
												<input type="submit" value="Yes"> <input type="button"
											value="No"
											onclick="javascript: window.location.href='?component=settings';">	
											<?php }?>	
											</div>

								</div>

							</form>


						</div>

					</div>

				</div>
			</div>
		</div>
	</div>
</div>