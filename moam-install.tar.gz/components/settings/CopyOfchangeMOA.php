<?php
// exit("bruno");
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 1);

Framework::includeLib("Utils.php");

if (! Framework::is_authentication())
    Framework::alert("Error: you do not have credentials.");

$error_msg = "";

if (isset($_POST['default'])) {

    if (strtolower($_POST['default']) == "update") {

        if (isset($_FILES['jarfile'])) {

            $files_extensions = array(
                "jar"
            );

            // $uploaddir = $base_directory_destine = dirname(__FILE__)."/../tests/".$folder;

            $uploaddir = Framework::getBase_directory_moa() . "bin/";
            $uploadfile = $uploaddir . Framework::getUser() . ".jar"; // basename($_FILES['spreadsheet']['name']);

            // verifica se arquivo existe em tmp
            if (is_uploaded_file($_FILES['jarfile']['tmp_name'])) {

                // verifica o formato da extensão do arquivo
                if (in_array(substr($uploadfile, strrpos($uploadfile, ".") + 1), $files_extensions)) {

                    // se o arquivo já existir, apaga
                    if (file_exists($uploadfile))
                        unlink($uploadfile);

                    // move o arquivo de tmp para destino
                    if (move_uploaded_file($_FILES['jarfile']['tmp_name'], $uploadfile)) {

                        // verifica se arquivo existe em destino
                        if (is_file($uploadfile)) {

                            // verifica se diretorio existe
                            if (! is_dir(Framework::getBase_directory_destine() . Framework::getUser())) {

                                // cria um novo diretório
                                if (mkdir(Framework::getBase_directory_destine() . Framework::getUser(), 0777, true))

                                    // define permissões ao diretório
                                    if (! chmod(Framework::getBase_directory_destine() . Framework::getUser(), 0777))
                                        $error_msg = "Error directory permissions.";
                                    else {

                                        // define permissões ao arquivo
                                        if (! chmod($uploadfile, 0777))
                                            $error_msg = "Error setting permissions.";
                                        else
                                            $error_msg = "Upload successful";
                                    }
                                else {
                                    $error_msg = "Error directory not create.";
                                }
                            } else {

                                // define permissoes ao arquivo
                                if (! chmod($uploadfile, 0777))
                                    $error_msg = "Error setting permissions.";
                                else
                                    $error_msg = "Upload successful";
                            }
                        } else
                            $error_msg = "Upload successful";
                    } else {
                        $error_msg = "lammer\n";
                    }
                } else {
                    $error_msg = "Extension not supported.";
                }
            } else {
                $error_msg = "file not exist.";
            }
        } else {
            $error_msg = "file not found.";
        }
    } else {

        if (file_exists(framework::getBase_directory_moa() . "bin/" . Framework::getUser() . ".jar"))
            unlink(framework::getBase_directory_moa() . "bin/" . Framework::getUser() . ".jar");

        $error_msg = "MOA default successful.";
    }
} else {
    // $error_msg = "Not defined fields";
}

?>



<div class="content content-alt">
	<div class="container" style="width: 70%">
		<div class="row">
			<div class="">
				<div class="card" style="width: 100%">



					<div class="page-header">
						<h1>MOA Binary</h1>
					</div>
							
							<?php

    if (! empty($error_msg)) {

        echo $error_msg;
    }
    ?>
							
							
							
            				<form method="POST"
						action="<?php echo $_SERVER['PHP_SELF'];?>" name="loginForm"
						enctype="multipart/form-data">
						<input type="hidden" value="<?php echo App::getComponent()?>"
							name="component"> <input type="hidden"
							value="<?php echo App::getController()?>" name="controller">

						<h2>Upload File</h2>
						<table>
							<tr>
								<td>MOA Binary Upload (*.jar):</td>
								<td><input type="file" name="jarfile" /></td>
								<td><input type="submit" name="default" value="update" /></td>
							</tr>
						</table>
						<input type="submit" name="default" value="default" />

					</form>


				</div>

			</div>
		</div>
	</div>
</div>
</div>

