<?php

// error_reporting(E_ALL | E_STRICT);
// ini_set('display_errors', 1);
if (! Framework::is_authentication())
    Framework::alert("Error: you do not have credentials.");

$extension_scripts = ".data";

Framework::includeLib("Utils.php");

$filename = App::getParameter("filename");
$folder = App::getParameter("folder");
$task = App::getParameter("task");
$id = App::getParameter("id");

$data = "";

if ($filename != null) {

    $utils = new Utils();

    $filename = App::getBase_directory_destine() . App::getUser() . 
    // .App::getDirectorySeparator()
    // .$dirScriptsName
    App::getDirectorySeparator() . $folder . 
    // .App::getDirectorySeparator()
    $filename;
    // .$extension_scripts
    

    Framework::includeLib("JsonFile.php");

    $jsonfile = new JsonFile();
    $jsonfile->open($filename);

    $data = $jsonfile->getDataKeyValue("id", $id);

    if ($task == "edit") {} else {

        if ($task == "save") {

            $data["process"] = false; // (strtolower(App::getParameter("process"))=="true"?true:false);
            $data["script"] = App::getParameter("data");
            $data["starttime"] = "";
            $data["endtime"] = "";
            $data["running"] = false;
            $data["pid"] = "";

            $dir = App::getBase_directory_destine() . App::getUser() . App::getDirectorySeparator() . $folder;

            $filename_ = substr($filename, strrpos($filename, "/") + 1);
            $filename_ = substr($filename_, 0, strrpos($filename_, "."));
            $filename_ = trim($filename_);
            $filename_ .= ".txt";

            $dir = substr($filename, 0, strrpos($filename, "/") + 1);
            $dir = trim($dir);

            $filename_ = substr($filename_, 0, strpos($filename_, ".")) . "-" . $id . ".txt";

            // echo $dir.$filename_;

            // echo $dir.$id."-".$filename_;

            if (file_exists($dir . $filename_)) {
                unlink($dir . $filename_);
            }

            $jsonfile->setDataKeyValue("id", $id, $data);

            // echo "<br><br><br><br>";

            $data = $jsonfile->getDataKeyValue("id", $id);

            // var_dump($data);exit($id);

            $jsonfile->save();
            $jsonfile->load();

            $data = $jsonfile->getDataKeyValue("id", $id);
        }
    }
}

$filename_element = substr(App::getParameter("filename"), 0, strpos(App::getParameter("filename"), ".")) . "-" . $id . ".txt";
// $filename_element = App::getUser()."/".$folder.$filename_element;

// exit($filename_element);

if ($data["process"] == false)
    $process = "false";
else
    $process = "true";

?>

<div class="content content-alt">
	<div class="container" style="width: 90%">
		<div class="row">
			<div class="">

				<div class="card" style="width: 100%">
					<div class="page-header">
						<h1>
							<a href="<?php echo $_SERVER['REQUEST_URI']?>">Report Script Edit</a>
						</h1>
					</div>

					<div style="width: 100%; padding-bottom: 15px; display: table">

						<div style="float: left; width: 200px; border: 1px solid #fff">
																
									<?php require_once("menu_features.php")?>								

								</div>

						<div style="float: left; width: 80%; border: 1px solid #fff">







							<form method="POST"
								action="<?php echo $_SERVER['PHP_SELF'];?>#save" name="saveform"
								async-form="login"
								class="ng-pristine ng-valid-email ng-invalid ng-invalid-required">
								<input type="hidden" value="<?php echo App::getComponent()?>"
									name="component"> <input type="hidden"
									value="<?php echo App::getController()?>" name="controller"> <input
									type="hidden" value="save" name="task" id="task"> <input
									type="hidden"
									value="<?php echo App::getParameter("filename");?>"
									name="filename"> <input type="hidden"
									value="<?php echo App::getParameter("folder");?>" name="folder">

								<div style="float: left; padding-left: 20px; width: 100%">

									<div
										style="float: left; padding-left: 5px; width: 100%; margin-top: 5px;">

										id: <br> <input type="text" style="width: 100%" name="id"
											value="<?php echo App::getParameter("id");?>"><br> script:<br>
										<textarea id="data" style="width: 100%; height: 400px;"
											name="data"><?php echo $data['script']?></textarea>
										<br> Process: <br> <select id="process" name="process">
											<option value="true">True</option>
											<option value="false">False</option>
										</select> <br> file name: <br>
												<?php

            $file = App::getBase_directory_destine() . App::getUser() . App::getDirectorySeparator() . $folder . $filename_element;

            if (file_exists($file)) {

                $filesize = $utils->filesize_formatted($file);
                ?>
													
												<?php echo $filename_element;?> <a target="_blank"
											href="<?php echo App::rootApp()."?component=resource&tmpl=false&task=open&file=".$folder.$filename_element;?>">
											[Open]</a> <a
											href="<?php echo App::rootApp()."?component=resource&tmpl=false&task=download&file=".$folder.$filename_element;?>">
											[Download]</a> <?php echo $filesize?><br>								
													
												
												<?php
            } else {

                echo "<b style='color:red'>file does not exist.</b>";
            }

            ?>
												
												<br>
										<br>*If save data, the file will be removed automatic.

									</div>


									<div style="float: right; padding-left: 5px">


										<a name="save"></a><input type="button" value="Return"
											name="return" onclick="javascript: returnPage();" /> <input
											type="submit" value="Save">

									</div>

								</div>

							</form>





						</div>

					</div>

				</div>
			</div>
		</div>
	</div>
</div>


<script>
function expand(id){

	if(id.alt=='' || id.alt === undefined){

		id.alt=id.text; 
		id.innerHTML=id.title;
	}else{
		id.innerHTML=id.alt; 
		id.alt='';
	}
}

function returnPage(){
	//window.history.go(-1);

	//http://localhost/iea/?component=moa&controller=reportview&filename=maciel.log&folder=New%20Folder/

		window.location.href='?component=<?php echo App::getParameter("component");?>'
			+'&controller=reportview'
			+'&filename=<?php echo App::getParameter("filename");?>'
			+'&folder=<?php echo App::getParameter("folder");?>';
		
}

function downloadfile(){

	window.location.href='?component=<?php echo App::getParameter("component");?>'
						+'&controller=reportscript'
						+'&filename=<?php echo App::getParameter("filename");?>'
						+'&folder=<?php echo App::getParameter("folder");?>';
	
}


function setSelectBox(Value, idSelectBox){

	var selectbox = document.getElementById(idSelectBox);

	for(i=0; i < selectbox.options.length; i++){

		if(selectbox.options[i].text.toLowerCase() == Value.toLowerCase()){
			selectbox.selectedIndex = i;
			break;
		}
			

	}
		
}

setSelectBox("<?php echo $process;?>", "process");
</script>

