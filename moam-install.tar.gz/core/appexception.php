<?php
/**
 * @package    moam\core
 *
 * @copyright  Copyright (C) 2015 - 2017 Open Source CIn/UFPE, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
namespace moam\core;

defined('_EXEC') or die();

class AppException extends CustomException
{
}

?>
