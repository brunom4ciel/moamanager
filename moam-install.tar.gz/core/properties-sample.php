<?php
/**
 * @package    MOAM.Application
 *
 * @copyright  Copyright (C) 2015 - 2017 Open Source CIn/UFPE, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
namespace moam\core;

defined('_EXEC') or die();

/**
 * Base class for a MOAM! application.
 */
abstract class Properties
{

    private static $acl_autoremove_account = true;

    public static $base_directory_destine = "/var/www/html/output/";

    public static $base_directory_destine_exec = "/var/www/html/tmp/";

    public static $base_directory_moa = "/opt/moa/";

    public static $base_directory_moa_jar_default = "moa2014.jar";

    public static $app_title = "MOAManager";

    // public static $passphrase = "2983590ygdoghdfghdfgf";
    public static $passphrase = "298350yqb";

    public static $base_directory = "/iea/";

    public static $file_contents_max_size = 500;

    // kb
    public static $file_java_exec = "java";

    public static $plivo_AUTH_ID = "BBBBBBBBBBBB";

    public static $plivo_AUTH_TOKEN = "ZjU5MGY2ZGMBBBBBBBBBzZTg4YTE1YTdhMTkwZjYzM2JkMTQ1";

    private static $database_name = "moamanagerdb";

    private static $database_host = "localhost";

    private static $database_user = "root";

    private static $database_pass = "123";

    private static $user_type_default = 2;

    private static $max_number_on_list_of_process="14";
    
    private static $output_directorys = array(
        "/var/www/html/output/",
        "/var/www/html/output2/",
        "/var/www/html/output1/"
    );

    
    /**
     * Get the value of the maximum number on list of process.
     *
     * @return integer
     */
    public static function getMax_number_on_list_of_process() {
        return self::$max_number_on_list_of_process;
    }
    
	/**
	 * Set default type of user.
	 * 
	 * @param string 	$type	type user
	 * 
	 * @return void
	 */
    public static function setUser_type_default($type)
    {
        self::$user_type_default = $type;
    }

	/**
	 * Get the value of the type of user.
	 *  
	 * @return integer
	 */
    public static function getser_type_default()
    {
        return self::$user_type_default;
    }

	
	/**
	 * defines whether the user can delete his own account.
	 * 
	 * @param boolean	$acl_autoremove_account	true | false value
	 * 
	 * @return void
	 */
    public static function setAcl_autoremove_account($acl_autoremove_account)
    {
        self::$acl_autoremove_account = $acl_autoremove_account;
    }

	/**
	 * get parameter that defines whether user can delete his own account.
	 * 
	 * @return	boolean
	 */
    public static function getAcl_autoremove_account()
    {
        return self::$acl_autoremove_account;
    }

	/**
	 * sets list of directories to manage user accounts.
	 * 
	 * @param mixed	$base_directory_destine	directory list
	 * 
	 * @return void
	 */
    public static function setBase_directory_destine($base_directory_destine)
    {
        self::$base_directory_destine = $base_directory_destine;
    }

	/**
	 * Get list of directories to manage user accounts. When passed as 
	 * a parameter the application instance is retrieved directly from 
	 * the directory in which the user belongs.
	 * 
	 * @param	string	$application instance of Application
	 * 
	 * @return	mixed	directory list
	 */
    public static function getBase_directory_destine($application = null)
    {
        $dirp_ = "";

        try {

            if ($application->is_authentication()) {
                $dirp_ = $application->getUserWorkspace();
            } else {
                $dirp_ = self::$base_directory_destine;
            }
            
        } catch (AppException $e) {

            throw new AppException($e->getMessage());
        }

        return $dirp_;
    }
    
	/**
	 * sets the default directory for temporary files.
	 * 
	 * @param	string	$base_directory_destine_exec directory
	 * 
	 * @return	void
	 */
    public static function setBase_directory_destine_exec($base_directory_destine_exec)
    {
        self::$base_directory_destine_exec = $base_directory_destine_exec;
    }

	/**
	 * get the default directory for temporary files.
	 * 
	 * @param	string	$base_directory_destine_exec directory
	 * 
	 * @return	void
	 */
    public static function getBase_directory_destine_exec()
    {
        return self::$base_directory_destine_exec;
    }

	/**
	 * sets the directory for moa framework
	 * 
	 * @param	string	$base_directory_moa directory
	 * 
	 * @return	void
	 */
    public static function setBase_directory_moa($base_directory_moa)
    {
        self::$base_directory_moa = $base_directory_moa;
    }
    
	/**
	 * get the directory for moa framework
	 * 
	 * @return	string
	 */
    public static function getBase_directory_moa()
    {
        return self::$base_directory_moa;
    }

	/**
	 * defines the name of the moa executable file, to be used as 
	 * the default in the application.
	 * 
	 * @param	string	$base_directory_moa_jar_default file name
	 * 
	 * @return	void
	 */
    public static function setBase_directory_moa_jar_default($base_directory_moa_jar_default)
    {
        self::$base_directory_moa_jar_default = $base_directory_moa_jar_default;
    }

	/**
	 * get the name of the moa executable file, to be used as 
	 * the default in the application.
	 * 
	 * @param	string	$base_directory_moa_jar_default file name
	 * 
	 * @return	void
	 */
    public static function getBase_directory_moa_jar_default()
    {
        return self::$base_directory_moa_jar_default;
    }

	/**
	 * sets the application's default title.
	 * 
	 * @param	string	$app_title title
	 * 
	 * @return	void
	 */
    public static function setApp_title($app_title)
    {
        self::$app_title = $app_title;
    }
	/**
	 * get the application default title.
	 * 
	 * @param	string	$app_title title
	 * 
	 * @return	void
	 */
    public static function getApp_title()
    {
        return self::$app_title;
    }
}

?>