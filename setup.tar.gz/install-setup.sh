#!/bin/bash


# by Bruno Maciel

dirbase=$(dirname $(readlink -f $0))
dirinstall="$dirmoam/install"

cd $dirinstall

sudo apt-get update

sh apache2-install.sh
sh curl-install.sh
sh mysql-install.sh
sh php-install.sh

service apache2 restart

sh moamanager-install.sh
sh java-install.sh
sh moa-install.sh
sh gcc-install.sh
sh libboost-install.sh
sh friedman-install.sh

