#!/bin/bash

echo "Install CURL"

sudo apt-get install curl -y



