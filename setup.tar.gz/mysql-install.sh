#!/bin/bash

echo "Install MySQL"

sudo apt-get install mysql-server -y

#sudo mysql_secure_installation

