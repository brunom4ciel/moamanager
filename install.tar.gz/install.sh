#!/bin/bash


# by Bruno Maciel


sh java-install.sh
sh mysql-install.sh
sh php-install.sh
sh curl-install.sh
sh gcc-install.sh
sh libboost-install.sh
sh friedman-install.sh
sh moa-install.sh
sh dump-database.sql
sh moamanager-install.sh
sh apache2-install.sh



