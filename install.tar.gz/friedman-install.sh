#!/bin/bash


# Install script for Latest MOAManager by Bruno Maciel

echo "Install script for Latest MOA by Bruno Maciel\n"

echo "Install friedman-test \n"

dirinstall="/opt"
dirbase="$dirinstall/moamanager"
dirbase_statistical="$dirbase/friedman-test/"
dirbase_statistical_src="$dirbase_statistical/src/"
dirbase_statistical_bin="$dirbase_statistical/bin/"

echo "create folder in path $dirbase"
mkdir -p $dirbase;

echo "create folder in path $dirbase_statistical"
mkdir -p $dirbase_statistical;

echo "create folder in path $dirbase_statistical_src"
mkdir -p $dirbase_statistical_src;

echo "create folder in path $dirbase_statistical_bin"
mkdir -p $dirbase_statistical_bin;

chmod 0777 -R $dirbase

cd $dirbase_statistical_src;

echo "Download latest statistical code and uncompress"

wget https://github.com/brunom4ciel/moamanager/raw/master/friedman-install.tar.gz

tar zxf friedman-install.tar.gz

rm friedman-install.tar.gz

chmod 0777 -R $dirbase

cd $dirbase_statistical_src

g++ $dirbase_statistical_src/friedman_run.cpp -std=c++11 -o3 -o $dirbase_statistical_bin/friedman_run

chmod 0777 $dirbase_statistical_bin/friedman_run

chmod +x $dirbase_statistical_bin/friedman_run



