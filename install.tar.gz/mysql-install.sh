#!/bin/bash

echo "Install MySQL"
sudo apt-get install mysql-server

