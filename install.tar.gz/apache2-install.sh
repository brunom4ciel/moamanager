#!/bin/bash


# by Bruno Maciel

echo "Install and configuration Apache\n"

#sudo apt-get install apache2

#cd /etc/apache2/sites-enabled/

#php_value upload_max_filesize 100M\nphp_value post_max_size 100M\nphp_value memory_limit 512M\n</VirtualHost>










