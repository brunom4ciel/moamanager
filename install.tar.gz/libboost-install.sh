#!/bin/bash

echo "Install lib boost"

sudo apt-get update
sudo apt-get install libboost-all-dev


