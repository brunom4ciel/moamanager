#!/bin/bash


# by Bruno Maciel

echo "Install JAVA"

sudo apt-get install ppa-purge -y
sudo apt-get install python-software-properties
sudo add-apt-repository ppa:webupd8team/java
sudo apt-get update
sudo apt-get install oracle-java8-installer
sudo apt-get install oracle-java8-set-default









